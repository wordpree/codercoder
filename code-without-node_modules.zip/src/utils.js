export const navMenu = {
  About: "/about",
  Products: "/products",
  Pricing: "/pricing",
  Blog: "/blog",
  Jobs: "/jobs",
};
