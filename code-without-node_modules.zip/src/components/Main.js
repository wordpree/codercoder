import React from "react";

const Main = () => {
  return <div>main</div>;
};

export default Main;
